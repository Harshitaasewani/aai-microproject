# Trust & Compliance Report — Aria Leather Crossbody Bag

**Case:** CASE-P001-20261020 · **Region:** IN · **As of:** 2026-10-20T12:00 UTC  
**Seller:** Aria Leather House (S001, account 21 days old)  
**Reviews:** 512 · **Avg rating:** 4.66★ · **Verified-purchase rate:** 0.34 · **Median reviewer account age at review:** 17.3 days

## Risk score: 95/100 — Critical
**Decision status:** `escalate` · **Routed to:** Trust & Safety — Seller Audit  
**Enforcement:** None taken automatically — all actions require human approval

## Summary

| Field | Value |
|---|---|
| Anomaly Detected | 331 reviews (314 five-star) in a 72-hour window (08 Oct 12:18–11 Oct 11:53 UTC) vs category baseline of 19/week — 17x the weekly baseline, 40x the expected 72h volume |
| Issue | 439 reviews (86%) from different accounts fall into 8 templated clusters; largest has 66 reviews. 112 reviews share the phrase pattern "exceeded my expectations will buy again" |
| Risk / Priority Level | Critical (95/100) |
| Explanation | Evidence is consistent with non-original product imagery, review volume spike, near-duplicate review text across accounts, coordinated reviewer network. The review burst is driven by a coordinated cluster of new, single-category accounts, matching a known incentivized review-ring signature. Seller account age (21 days) is inconsistent with its review volume and the seller has recent flags on file. The product photo is not original: the same image appears on listings of unrelated sellers. Material/origin/certification claims in the listing have no supporting documents on file. |
| Recommendation | Escalate to compliance for seller audit (coordinated review activity); Suppress rating badge pending investigation; Hold suspected reviews (~86% of total) out of the star rating pending human review |

## Agent scores

| Agent | Risk signal (0-1) | Confidence | Summary |
|---|---|---|---|
| Statistical Anomaly | 0.90 | 1.00 | Peak 331 reviews/72h vs baseline 19/week; 88% five-star. |
| Linguistic Pattern | 0.89 | 1.00 | Linguistic authenticity score 0.11/1.0 |
| Reviewer Network | 1.00 | 1.00 | 439 of 512 reviewers in coordinated clusters; linked sellers: ['S002'] |
| Product Claim Verification | 0.84 | 0.80 | 2 claims extracted, 2 unverified |
| Visual Counterfeit Signal | 0.85 | 0.75 | Image reused by 4 unrelated sellers |
| Seller Risk Correlation | 1.00 | 0.85 | Seller Aria Leather House (21d old) — risk tier High |

## Findings (audit trail)

| ID | Severity | Finding | Policy clause | Regulatory reference | Evidence |
|---|---|---|---|---|---|
| F-001 | high | **Non-original product imagery** — Listing image matches photos used by 4 unrelated seller(s) in the past 60 days (perceptual-hash distance ≤ 24/256) | Policy 5.3: Misappropriated Product Imagery | Trade Marks Act, 1999 | 4 item(s), sha256 `badfbf58e95e…` |
| F-002 | critical | **Review volume spike** — 331 reviews (314 five-star) in a 72-hour window (08 Oct 12:18–11 Oct 11:53 UTC) vs category baseline of 19/week — 17x the weekly baseline, 40x the expected 72h volume | Policy 3.1: Review Manipulation | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 331 item(s), sha256 `6ac807549d5d…` |
| F-003 | critical | **Near-duplicate review text across accounts** — 439 reviews (86%) from different accounts fall into 8 templated clusters; largest has 66 reviews. 112 reviews share the phrase pattern "exceeded my expectations will buy again" | Policy 3.4: Inauthentic Review Content | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 5 item(s), sha256 `bc9133615768…` |
| F-004 | critical | **Coordinated reviewer network** — 439 reviewer accounts in 1 cluster share devices or IP ranges with accounts created within 5 days of each other (largest cluster 439; 28 devices, 5 IP ranges) | Policy 3.2: Coordinated / Fake Reviewer Accounts | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 1 item(s), sha256 `9f5437bdf192…` |
| F-005 | high | **Generic superlatives without product detail** — 86% of reviews use generic praise and mention no product-specific detail (e.g. strap, zipper, stitching for this category) | Policy 3.4: Inauthentic Review Content | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 439 item(s), sha256 `9f3ab77de448…` |
| F-006 | high | **Accounts created in the same window** — 439 reviewer accounts (86%) were created within the same 5-day window starting 21 Sep 2026 | Policy 3.2: Coordinated / Fake Reviewer Accounts | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 0 item(s), sha256 `4f53cda18c2b…` |
| F-007 | high | **Reviewers exclusive to this seller network** — 349 reviewers (68%) have only ever reviewed this seller's catalog; 86% review only this seller and linked seller(s) S002 — reciprocal review pattern | Policy 3.2: Coordinated / Fake Reviewer Accounts | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 60 item(s), sha256 `3f2d52b32f46…` |
| F-008 | high | **Seller age inconsistent with review volume** — Account is 21 days old but has 645 reviews across 2 listing(s) (30.7/day vs category ~2.8/day per listing) | Policy 7.2: Seller Integrity / Repeat Offender | — | 0 item(s), sha256 `4f53cda18c2b…` |
| F-009 | high | **Prior flags / warnings on file** — 2 flag(s) and 0 warning(s) in the last 30 days | Policy 7.2: Seller Integrity / Repeat Offender | — | 4 item(s), sha256 `fac94536eb71…` |
| F-010 | high | **Rapid relisting after takedown** — 1 listing(s) re-created within 7 days of a takedown | Policy 7.2: Seller Integrity / Repeat Offender | — | 1 item(s), sha256 `c3af5c3996cb…` |
| F-011 | high | **Unverified material claim** — Listing claims "genuine leather" but no supplier/certification document is on file | Policy 4.2: Deceptive Product Description | Consumer Protection Act, 2019 (misleading advertisement); Consumer Protection (E-Commerce) Rules, 2020 | 1 item(s), sha256 `5623078f98b9…` |
| F-012 | high | **Unverified origin claim** — Listing claims "handcrafted in italy" but no supplier/certification document is on file | Policy 4.2: Deceptive Product Description | Consumer Protection Act, 2019 (misleading advertisement); Consumer Protection (E-Commerce) Rules, 2020 | 1 item(s), sha256 `59b898a4b5a5…` |
| F-013 | medium | **Unnatural 5-star clustering** — 88% of ratings are 5★ vs 59% in category (JS divergence 0.07) | Policy 3.1: Review Manipulation | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 0 item(s), sha256 `4f53cda18c2b…` |
| F-014 | medium | **Timing inconsistent with organic traffic** — 65% of all reviews landed in one 72h window; hour-of-day pattern diverges from category traffic (JS 0.04) | Policy 3.1: Review Manipulation | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 0 item(s), sha256 `4f53cda18c2b…` |
| F-015 | medium | **Price cut coinciding with review burst** — Price fell 75% (₹3999 → ₹999) during the review spike, then was restored | Policy 6.1: Pricing Manipulation | Consumer Protection Act, 2019 (misleading advertisement); Consumer Protection (E-Commerce) Rules, 2020 | 3 item(s), sha256 `d62ce7b31fa2…` |
| F-016 | medium | **Low reviewer order-history diversity** — 86% of reviewers are single-category purchasers with ≤3 lifetime orders | Policy 3.2: Coordinated / Fake Reviewer Accounts | Consumer Protection Act, 2019 (unfair trade practices); BIS IS 19000:2022 online consumer reviews standard | 0 item(s), sha256 `4f53cda18c2b…` |

## Recommended actions (for human approval)

- Escalate to compliance for seller audit (coordinated review activity)
- Suppress rating badge pending investigation
- Hold suspected reviews (~86% of total) out of the star rating pending human review
- Request supporting documents for: "genuine leather", "handcrafted in italy"
- Review all active listings of this seller for relisting evasion

## Historical precedent

100% of the 25 most similar past cases were confirmed review fraud.

Outcome mix: confirmed review fraud 100%

---
*Generated by TrustGuard (PS-13 prototype). This report is a detection and evidence layer; it is not an enforcement decision.*